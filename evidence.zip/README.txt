The Quiet Rewrite — public evidence package
Prepared 28 October 2026.

The source PDF is byte-identical to the retained original. Sources/ contains policy snapshots, extracted texts, archive comparisons, retrieval receipts and verification records. SOURCE_INDEX.json explains evidence types. A parsed excerpt is not represented as original HTTP bytes.

Response cookies and local filesystem paths have been redacted in public JSON derivatives. Public correspondence is plain text with private transport headers, tracking HTML, private ticket links and routing identifiers removed. evidence-manifest.json records original and published SHA-256 values. The Mistral account export is excluded as unrelated private material.

A hash supports later comparison; it does not independently prove a document date or truth. Government disclosure clauses document permitted circumstances, not proof of access to a particular person’s files. The unchanged Dropbox government-disclosure section is recorded in dropbox-government-comparison.json.

Third-party documents remain the property of their respective authors. This publication adds no blanket licence over them.
